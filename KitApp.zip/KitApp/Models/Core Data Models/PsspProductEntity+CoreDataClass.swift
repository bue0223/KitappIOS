//
//  PsspProductEntity+CoreDataClass.swift
//  KitApp
//
//  Created by Kenneth Esguerra on 8/12/20.
//  Copyright © 2020 Kenneth Esguerra. All rights reserved.
//
//

import Foundation
import CoreData

@objc(PsspProductEntity)
public class PsspProductEntity: NSManagedObject {

}
