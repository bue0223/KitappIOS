//
//  SpreadSheetItemViewModel.swift
//  KitApp
//
//  Created by Kenneth Esguerra on 7/15/20.
//  Copyright © 2020 Kenneth Esguerra. All rights reserved.
//

import Foundation

protocol SpreadsheetItemViewModel {
    //var columnViewModels: [RowViewModel] { get set }
    
    var rowHeight: Float {
        get
    }
}
