//
//  StringExtensions.swift
//  KitApp
//
//  Created by Kenneth Esguerra on 5/21/20.
//  Copyright © 2020 Kenneth Esguerra. All rights reserved.
//
